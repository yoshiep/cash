<?php

  $conn = mysqli_connect('localhost','idex2683_cash','eYsPN}o42(kl','idex2683_cash') or die($conn);

?>
