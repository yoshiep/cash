<?php

  $conn = mysqli_connect('localhost','root','K0taBerawalanZ','cash') or die($conn);

?>
