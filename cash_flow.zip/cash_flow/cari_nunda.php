<?php
$cari=$_GET['cari'];
header("location: nunda_kas.php?cari=$cari");
?>
